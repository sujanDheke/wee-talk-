-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2024 at 05:10 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `we-talk`
--

-- --------------------------------------------------------

--
-- Table structure for table `delete_user`
--

CREATE TABLE `delete_user` (
  `del_req_id` int(255) NOT NULL,
  `delete_user_email` varchar(255) NOT NULL,
  `delete_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `feedback` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_email`, `feedback`) VALUES
(1, 'samsung@gmail.com', 'Your application is so good..');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL,
  `incoming_msg_id` varchar(255) NOT NULL,
  `outgoing_msg_id` varchar(255) NOT NULL,
  `msg` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`msg_id`, `incoming_msg_id`, `outgoing_msg_id`, `msg`) VALUES
(151, '167671996', '725618500', 0x66793fe744bd98004d69eb98427d3f),
(152, '725618500', '167671996', 0x6679402d5fbfc800e3c17c3829),
(153, '167671996', '725618500', 0x6679406ed6f39000222f3f7d02f53281b844),
(154, '725618500', '167671996', 0x6679409d97460400ea49746462613aca0d042f44f1),
(155, '167671996', '725618500', 0x667940a477966c00b6b753fae0);

-- --------------------------------------------------------

--
-- Table structure for table `update_password`
--

CREATE TABLE `update_password` (
  `id` int(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `new_password` varchar(255) NOT NULL,
  `update_psw_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users_registration`
--

CREATE TABLE `users_registration` (
  `user_id` int(100) NOT NULL,
  `unique_id` int(200) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_phone` varchar(10) NOT NULL,
  `user_address` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_image` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `delete_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_registration`
--

INSERT INTO `users_registration` (`user_id`, `unique_id`, `user_name`, `user_phone`, `user_address`, `user_email`, `user_password`, `user_image`, `status`, `delete_status`) VALUES
(24, 725618500, 'Kaji', '9856473980', 'Kalimati', 'kajihero@gmail.com', 'p@ssword1', '16959850485.jpg', 'Active now', ''),
(26, 167671996, 'Ritesh', '9845673846', 'Kalimati', 'ritesh@gmail.com', 'ritesh@12', '16960705331.jpg', 'Active now', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `delete_user`
--
ALTER TABLE `delete_user`
  ADD PRIMARY KEY (`del_req_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `update_password`
--
ALTER TABLE `update_password`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_registration`
--
ALTER TABLE `users_registration`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `delete_user`
--
ALTER TABLE `delete_user`
  MODIFY `del_req_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `update_password`
--
ALTER TABLE `update_password`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users_registration`
--
ALTER TABLE `users_registration`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
