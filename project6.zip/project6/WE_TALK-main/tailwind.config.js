module.exports = {
  content: ["./src/*.{html,php,js}"],
  theme: {
    extend: {
      colors: {
        emerald: "#34D399",
      },
    },
  },
  plugins: [],
};
